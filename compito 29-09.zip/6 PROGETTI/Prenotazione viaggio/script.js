let prenotazioni = [];

function aggiungiPrenotazione() {
    let nome = document.getElementById("nome").value;
    let cognome = document.getElementById("cognome").value;
    let email = document.getElementById("email").value;
    let destinazioneInfo = document.getElementById("destinazione").value.split('-');
    let destinazione = destinazioneInfo[0];
    let costo = parseInt(destinazioneInfo[1]);
    let dataPartenza = document.getElementById("dataPartenza").value;
    let passeggeri = parseInt(document.getElementById("passeggeri").value);

    if (nome === "" || cognome === "" || email === "" || dataPartenza === "" || isNaN(passeggeri)) {
        alert("Tutti i campi devono essere compilati");
        return;
    }

    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Inserisci un'email valida");
        return;
    }

    let costoTotale = costo * passeggeri;

    let prenotazione = {
        nome: nome,
        cognome: cognome,
        email: email,
        destinazione: destinazione,
        dataPartenza: dataPartenza,
        passeggeri: passeggeri,
        costoTotale: costoTotale
    };

    prenotazioni.push(prenotazione);
    aggiornaTabella();

    document.getElementById("prenotazioneForm").reset(); // Reset del modulo
}

function aggiornaTabella() {
    let elencoPrenotazioni = document.getElementById("elencoPrenotazioni").getElementsByTagName('tbody')[0];
    elencoPrenotazioni.innerHTML = ""; // Pulisce la tabella

    prenotazioni.forEach((prenotazione, index) => {
        let riga = document.createElement("tr");

        riga.innerHTML = `
            <td>${prenotazione.nome}</td>
            <td>${prenotazione.cognome}</td>
            <td>${prenotazione.email}</td>
            <td>${prenotazione.destinazione}</td>
            <td>${prenotazione.dataPartenza}</td>
            <td>${prenotazione.passeggeri}</td>
            <td>${prenotazione.costoTotale}€</td>
            <td><button class="rimuovi" onclick="rimuoviPrenotazione(${index})">Rimuovi</button></td>
        `;

        elencoPrenotazioni.appendChild(riga);
    });

    document.getElementById("riepilogo").style.display = prenotazioni.length > 0 ? 'block' : 'none'; // Mostra o nasconde la tabella
}

function rimuoviPrenotazione(index) {
    prenotazioni.splice(index, 1);
    aggiornaTabella();
}
