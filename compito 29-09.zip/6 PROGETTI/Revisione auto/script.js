let people = [];

function calcolaTotale() {

    let nome = document.getElementById("nome").value;
    let cognome = document.getElementById("cognome").value;
    let email = document.getElementById("email").value;
    let olio = document.getElementById("olio").value;
    let freni = document.getElementById("freni").value;
    let gomme = document.getElementById("gomme").value;

    if (nome === "" || cognome === "" || email === "") {
        alert("Tutti i campi devono essere compilati");
        return;
    }

    
    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Inserisci un'email valida");
        return;
    }


    let totale = 0;

    if (document.getElementById('olio').checked) {
        totale += 50;
    }
    if (document.getElementById('freni').checked) {
        totale += 200;
    }
    if (document.getElementById('gomme').checked) {
        totale += 300;
    }

    document.getElementById('totale').innerHTML = "Totale: " + totale + "€";
}
